package s18cs350task3;
/*
 * Preston Tomes
 */
public interface I_Updateable {

	public void update_();
}
