package s18cs350task3;
/**
 * 
 * @author ptomes
 * Preston Tomes
 */
public class AgentMover implements I_Updateable {

	private double x;
	private double y;
	private double z;
	private double speed;
	private double speedDeltaAccelerate;
	private double speedDeltaDecelerate;
	private double speedMax;
	private double azimuth;
	private double azimuthDelta;
	private double altitudeDelta;
	
	private double speedTarget;
	private double azimuthTarget;
	private double speedMin;
	private double altitudeTarget;
	private boolean isClockwise;
	
	/**
	 * This is a constructor 
	 * @param x  x-position
	 * @param y	 y-position
	 * @param z	 z-position
	 * @param speed  Current Speed
	 * @param speedDeltaAccelerate Acceleration Rate
	 * @param speedDeltaDecelerate Deceleration Rate
	 * @param speedMax Max Speed cannot be higher
	 * @param azimuth current direction in x,y plane
	 * @param azimuthDelta rate of direction change
	 * @param altitudeDelta rate of altitude change
	 */
	public AgentMover(double x,
	double y,
	double z,
	double speed,
	double speedDeltaAccelerate,
	double speedDeltaDecelerate,
	double speedMax,
	double azimuth,
	double azimuthDelta,
	double altitudeDelta){
		try {
		this.x=x;
		this.y=y;
		this.z=z;
		this.speed=speed;
		
		this.speedDeltaAccelerate=speedDeltaAccelerate;
		this.speedDeltaDecelerate=speedDeltaDecelerate;
		this.speedMax=speedMax;
		this.azimuth=azimuth;
		this.azimuthDelta=azimuthDelta;
		this.altitudeDelta=altitudeDelta;
		}
		catch(Exception e){
			throw new RuntimeException("Entered Invalid Values in method AgentMover Constructor");
		}
		if(speed>speedMax) {
			throw new RuntimeException("Speed is Greater then Max Speed at Constructor");
			
		}
		if(azimuth<0 || azimuth >=360) {
			throw new RuntimeException(" Azimuth is greater then 360 or below 0");
			
		}
		
		if(speedDeltaAccelerate<0) {
			throw new RuntimeException(" SpeedADelta cannont be less then 0");
			
		}
		if(speedDeltaDecelerate<0) {
			throw new RuntimeException(" SpeedDDelta cannont be less then 0");
			
		}
		if(azimuthDelta<0 || azimuthDelta >=360) {
			throw new RuntimeException(" Azimuth is greater then 360 or below 0");
			
		}
		if(altitudeDelta<0) {
			throw new RuntimeException(" altitudeDelta can not be less then 0");
			
		}
		
		if(speed<0) {
			throw new RuntimeException(" Speed cannot be less then 0");
			
		}
		
		
		
		
		this.speedTarget=speed;
		this.azimuthTarget=azimuth;
		this.altitudeTarget=z;

	}
	
	/**
	 *  get altitude change rate
	 * @return altitude change rate
	 */
	public double getAltitudeDelta(){
	//Gets the rate by which the altitude changes toward the target altitude.
	if(altitudeDelta<0){
		throw new RuntimeException("Altitude Delta is Negative");
	}
	return altitudeDelta;
	}
	
	public double getAzimuth(){
		//Gets the current azimuth of the agent.
		
		if(azimuth>=360){
			throw new RuntimeException("Azimuth is Greater then 360");
		}
		return azimuth;
	}
	
	/**
	 *  get azimuth change rate
	 * @return azimuth change rate
	 */
	public double getAzimuthDelta(){
	//Gets the angle by which the azimuth changes toward the target azimuth.
	
		if(azimuthDelta>=360){
			throw new RuntimeException("Azimuth Delta is Greater then 360 ");
		}
		
		if(azimuthDelta<0)
		{
			throw new RuntimeException("Azimuth Delta is less then 0 ");
		}
		
		
		return azimuthDelta;
	}
	
	/**
	 *  get azimuth Target direction
	 * @return Target Direction
	 */
	public double getAzimuthTarget(){
	//Gets the azimuth the agent must attain.
	
		if(azimuthTarget>=360){
			throw new RuntimeException("Azimuth Target is Greater then or equal to 360 ");
		}
		
		if(azimuthTarget<0)
		{
			throw new RuntimeException("Azimuth Target is less then 0 ");
		}
		
		return azimuthTarget;
	}
	/**
	 *  get speed
	 * @return Speed
	 */
	public double getSpeed(){
	//Gets the current speed of the agent.
		
		if(speed>speedMax){
			throw new RuntimeException("Speed is Greater then Max Speed ");
		}
		
		if(speed<0)
		{
			throw new RuntimeException("Speed can not be Negative ");
		}
		return speed;
	}
	
	/**
	 *  get Acceleration change rate
	 * @return Acceleration change rate
	 */
	public double getSpeedDeltaAccelerate(){
	//Gets the delta speed of the agent for acceleration to the target speed.
	
		if(speedDeltaAccelerate>speedMax){
			throw new RuntimeException("Speed Delta Accelerate is greater then Max Speed ");
		}
		
		if(speedDeltaAccelerate<0)
		{
			throw new RuntimeException("Speed Delta Accelerate can not be Negative ");
		}
		
	
		return speedDeltaAccelerate;
	}
	
	/**
	 *  get Deceleration change rate
	 * @return Deceleration change rate
	 */
	
	public double getSpeedDeltaDecelerate(){
	//Gets the delta speed of the agent for deceleration to the target speed.
		if(speedDeltaDecelerate<0)
		{
			throw new RuntimeException("Speed Delta Decelerate can not be Negative ");
		}
		return speedDeltaDecelerate;
		
	}
	/**
	 *  get Max Speed 
	 * @return Max Speed
	 */
	
	public double getSpeedMax(){
	//Gets the maximum speed the agent may attain.
	if(speedMax<=0){
		throw new RuntimeException("Max Speed Cannot be 0 or negative");
	}
		return speedMax;
	}
	
	/**
	 *  get speed min
	 * @return speed min
	 */
	public double getSpeedMin(){
	//Gets the minimum speed the agent may attain.
		
		if(speedMin<0){
			throw new RuntimeException("Min Speed Cannot be less then 0 or negative");
		}
	return 0;
	}
	
	/**
	 *  get Target speed
	 * @return Target Speed
	 */
	public double getSpeedTarget(){
	//Gets the speed the agent must attain.
	if(speedTarget>speedMax){
		throw new RuntimeException("Target Speed cannot be greater then Max Speed");
	}
	if(speedTarget<0){
		throw new RuntimeException("Target Speed cannot less then 0");
	}
		
		return speedTarget;
	}
	
	/**
	 *  get X position
	 * @return x position
	 */
	public double getX(){
	//Gets the x position of the agent.
	
		return x;
	}
	/**
	 *  get Y position
	 * @return Y position
	 */
	public double getY(){
	//Gets the y position of the agent.
	return y;
	}
	
	/**
	 *  get Z position
	 * @return Z position
	 */
	public double getZ(){
	//Gets the z position of the agent.
	return z;
	}
	
	
	/**
	 *  check if target Altitude is reached
	 * @return return if reached true/false
	 */
	public boolean hasAttainedTargetAltitude(){
	//Gets whether the target altitude has been attained.
	if(Double.compare(z,altitudeTarget)==0){
		return true;
	}
	return false;
	}
	
	/**
	 *  check if target Azimuth is reached
	 * @return return if reached true/false
	 */
	public boolean hasAttainedTargetAzimuth(){
	//Gets whether the target azimuth has been attained.
	if(Double.compare(azimuthTarget,azimuth)==0){
		return true;
	}
	return false;
	}
	
	/**
	 *  check if target Speed is reached
	 * @return return if reached true/false
	 */
	public boolean hasAttainedTargetSpeed(){
	//Gets whether the target speed has been attained.
	if(Double.compare(speedTarget,speed)==0){
		return true;
	}
	
	return false;
	}
	
	/**
	 *  check if Clockwise or not is reached
	 * @return return true if clockwise true else false
	 */
	public boolean isAzimuthTargetClockwise(){
	//Gets whether to turn clockwise (otherwise counterclockwise) 
		// toward the target azimuth.
		return isClockwise;
		
		
	}
	
	/**
	 *  Check a maximum Distance between to points
	 * @param x x position of second point
	 * @param y y position of second point
	 * @param z z position of second point
	 * @param distance maximum distance
	 * @return True if within the maximum distance otherwise false
	 */
	public boolean isProximate(double x, double y, double z, double distance){
	//Determines whether the agent is within a certain distance of a point.
	
		try{
		double a=x-this.x;
		double b=y-this.y;
		double c=z-this.z;
			
		a=a*a;
		b=b*b;
		c=c*c;
		
		double total=a+b+c;
		total=Math.sqrt(total);
		if(total<distance){
			return true;
		}
		
		}
		catch(Exception e){
			throw new RuntimeException("Entered Invalid Values in method isProximate");
		}
		return false;
		
	}
	/**
	 * Set Target Altitude
	 * @param altitude Target Altitude
	 */

	public void setAltitudeTarget(double altitude){
	//Sets the altitude the agent must attain.
		try{
			altitudeTarget=altitude;
		}
		catch(Exception e){
			throw new RuntimeException("Entered Invalid Values in method setAltitudeTarget");
		}
	}
	
	/** Set Target Azimuth
	 * 
	 * @param azimuth Target Azimuth
	 * @param isClockwise turn clockwise if true or counter clockwise if false
	 */
	public void setAzimuthTarget(double azimuth, boolean isClockwise){
	//Sets the azimuth the agent must attain.
		try{
			if(azimuth>=360 || azimuth<0){
				throw new RuntimeException("Target Azmuth is not in Acceptable Range 0-359");
			}
			azimuthTarget=azimuth;
			this.isClockwise=isClockwise;
		}
		catch(Exception e){
			throw new RuntimeException("Entered Invalid Values in method setAzimuthTarget");
		}
		
	}
	

	/**Set Target Speed
	 *
	 * @param speed is Target Speed
	 */
	public void setSpeedTarget(double speed){
	//Sets the speed the agent must attain.
		try{
			if(speed>speedMax || speed<0){
				throw new RuntimeException("Speed Target is Less then 0 or Above Max Speed");
			}
			speedTarget=speed;
			
		}
		catch(Exception e){
			throw new RuntimeException("Entered Invalid Values in method setSpeedTarget");
		}
		
	}

	/**
	 * update current postion and speed and azimuth
	 */
	@Override
	public void update_() {
		
		
		//Azimuth Delta Movement
		if( hasAttainedTargetAzimuth()==false) {
			
			if(isAzimuthTargetClockwise()==true) {//Clockwise
				double tester=(azimuthTarget-azimuthDelta)%360;
				double tester1=390;
				if(tester<0) {
					tester1=360+tester;
				}
				//if(tester<azimuth && azimuth<azimuthTarget) {
				if(azimuth>azimuthTarget && azimuth>tester1 || azimuth>azimuthTarget-azimuthDelta &&azimuth<azimuthTarget) {
					azimuth=azimuthTarget;
				}
				else {
					azimuth=(azimuth+azimuthDelta)%360;
				}
				
			}
			
			else {//Not Clockwise
				double tester=(azimuthTarget+azimuthDelta);
				
				
				if(azimuth>=0&& azimuth<(azimuthTarget+azimuthDelta)%360 &&tester>360  || azimuth>azimuthTarget&& azimuth<azimuthTarget+azimuthDelta) {
					azimuth=azimuthTarget;
				}
				
				else {
					tester=(azimuth-azimuthDelta)%360;
					if(tester<0) {
						tester=360+tester;
					}
					azimuth=tester;
				}
				
			}
			
		}//End Azimuth Delta Movement
		
		//Speed Delta
		if(hasAttainedTargetSpeed()==false) {
			if(speedTarget>speed) {//speeding up
				if(speed+speedDeltaAccelerate>=speedTarget) {//OverSpeed Adjustment
					speed=speedTarget;
				}
				else {
					speed=speed+speedDeltaAccelerate;
				}
				
				
			}
			else if(speedTarget<speed){ //speeding down
				if(speed-speedDeltaDecelerate<=speedTarget) {//UnderSpeed Adjustment
					speed=speedTarget;
				}
				else {
					speed=speed-speedDeltaDecelerate;
				}
				
			}
		}
		//End Speed Delta
		
		//Postion Update
		//x y
		if(azimuth<90 && azimuth>0) {//(0 to 90)
			x=x+Math.sin(Math.toRadians(azimuth))*speed;
			y=y+Math.cos(Math.toRadians(azimuth))*speed;
		}
		else if(azimuth<180 && azimuth>90) {//(90 to 180)
			double tester=azimuth-90;
			y=y-Math.sin(Math.toRadians(tester))*speed;
			x=x+Math.cos(Math.toRadians(tester))*speed;
		}
		else if(azimuth<270 && azimuth>180) {//(180 to 270)
			double tester=azimuth-180;
			x=x-Math.sin(Math.toRadians(tester))*speed;
			y=y-Math.cos(Math.toRadians(tester))*speed;
		}
		else if(azimuth<360 && azimuth>270) {//(270 360)
			double tester=azimuth-270;
			y=y+Math.sin(Math.toRadians(tester))*speed;
			x=x-Math.cos(Math.toRadians(tester))*speed;
		}
		
		else if(azimuth==0) {
			y=y+Math.cos(Math.toRadians(azimuth))*speed;
		}
		else if(azimuth==90) {
			x=x+Math.sin(Math.toRadians(azimuth))*speed;
		}
		else if(azimuth==180) {
			double tester=azimuth-90;
			y=y-Math.sin(Math.toRadians(tester))*speed;
		}
		else if(azimuth==270) {
			double tester=azimuth-270;
			x=x-Math.cos(Math.toRadians(tester))*speed;
		}
		//end x y
		
		//z
		if(hasAttainedTargetAltitude()==false) {
			if(altitudeTarget>z) {//Altitude Up
				if(z+altitudeDelta>=altitudeTarget) {//Over Target Altitude Adjustment
					z=altitudeTarget;
				}
				else {
					z=z+altitudeDelta;//Ascend z
				}
				
				
			}
			else {// Altitude Down
				if(z-altitudeDelta<=altitudeTarget) {//Under Target Altitude Adjustment
					z=altitudeTarget;
				}
				else {
					z=z-altitudeDelta;//Descend z
				}
				
			}
		}
		
		//end z
		
		
		//End Postion Update
	}//End of Updater
	public String toString() {
		String x="X:"+this.x+" Y:"+this.y+" Z:"+this.z+" Speed:"+this.speed+" Azimuth:"+this.azimuth;
		return x;
	}
	
}//End of Agent Mover

/*
	double x;
	double y;
	double z;
	double speed;
	double speedDeltaAccelerate;
	double speedDeltaDecelerate;
	double speedMax;
	double azimuth;
	double azimuthDelta;
	double altitudeDelta;
	
	double speedTarget;
	double azimuthTarget;
	double speedMin;
	double altitudeTarget;
	boolean isCloakwise;
*/
