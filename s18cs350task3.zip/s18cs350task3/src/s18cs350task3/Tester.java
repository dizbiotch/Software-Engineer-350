package s18cs350task3;

public class Tester {

	public static void main(String[] args) {
										// x	y	z	speed	speedDA		speedDD		SpeedMax	Azimuth		AzimuthD	AltitudeD
		AgentMover tester=new AgentMover(	0,	0,	1,		10	,	2		,3			,25			,90		,90		,1);
		
		System.out.println(tester.toString());
		tester.update_();
		System.out.println(tester.toString());
		
		tester.setAzimuthTarget(0, true);
		tester.update_();
		System.out.println(tester.toString());
		
		tester.update_();
		System.out.println(tester.toString());
		
		tester.update_();
		System.out.println(tester.toString());
		
		tester.update_();
		System.out.println(tester.toString());
		
		tester.update_();
		System.out.println(tester.toString());
		
		tester.setSpeedTarget(20);
		
		tester.update_();
		System.out.println(tester.toString());
		tester.update_();
		System.out.println(tester.toString());
		
	}
}

